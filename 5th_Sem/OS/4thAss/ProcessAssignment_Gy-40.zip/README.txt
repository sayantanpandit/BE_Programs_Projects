
This zip file contains three subprograms(i.e Add, Substraction, Multiply) as an example and one main program to execute all the subprograms.

A. Addition(1st Example)
   1. Add        - Executable file for the Add.c
   2. Add.c      - C Program for addition
   3. AddIn.txt  - User's Input of 2 numbers
   4. AddOut.txt - Output according to User's Input given in AddIn.txt

B. Substraction(2nd Example)
   1. Sub        - Executable file for the Sub.c
   2. Sub.c      - C Program for Substraction
   3. SubIn.txt  - User's Input of 2 numbers
   4. SubOut.txt - Output according to User's Input given in SubIn.txt

C. Multiply(3rd Example)
   1. Mult        - Executable file for the Mult.c
   2. Mult.c      - C Program for Multiplication
   3. MultIn.txt  - User's Input of 2 numbers
   4. MultOut.txt - Output according to User's Input given in AddIn.txt

D. Process Abstraction
   1. ProcessConti   -  Executable file for the Process Abstraction
   2. ProcessConti.c -  C Program


How to run the program?
1. First create C program file as <filename>.c
2. Create <filename>In.txt for that file
3. Create <filename>Out.txt for that file
2. Then run the C Program as this : 
   cc <filename>.c -o <filename>
   This is done to differentiate the executable file between the other programs
3. Run the final program as :
   ./ProcessConti.c <filename> <filename>In.txt <filename>Out.txt
   
Example : 
A.  To run sub-programs along main-program include in this folder
    ./ProcessConti Add AddIn.txt AddOut.txt Sub SubIn.txt SubOut.txt Mult MultIn.txt MultOut.txt

B. Output 
     Open AddOut.txt, SubOut.txt, MultOut.txt
C. You can change the input value in this file : 
     AddIn.txt, SubIn.txt, MultIn.txt

 Again run the step no. A to see the change in output file..


Thanks You
/*********************************Made by SAYANTAN PANDIT**************************************/
